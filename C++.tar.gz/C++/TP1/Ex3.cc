#include <iostream>
using namespace std;
#include <stdlib.h>

int main (int agrc, char** agrv)
{
  int n=atoi(agrv[1]);
  if (n==1)
    return 1;

  if (n==2)
	return 1;
  else
    {
      int u1,u2,u3,i;
      u1=1;
      u2=1;

      for (int i=3; i<=n; i++)
	{
	  u3=u2+u1;
	  u1=u2;
	  u2=u3;
	}
return u3;
    }
  return -1;
}
