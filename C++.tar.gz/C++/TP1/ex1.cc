#include <iostream>
using namespace std;

int print_Bonjour()
{
  cout <<"Bonjour"<< endl;
  return 0;
}

int main()
{
  print_Bonjour() ;
}
