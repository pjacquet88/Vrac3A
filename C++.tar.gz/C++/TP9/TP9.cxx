#include "TP9.hxx"
#include "Mesh2D.cxx"


#include <complex.h> 
template<class T>
HelmholtzProblem<T>:: HelmholtzProblem()
{
	
	  //! pulsation omega
omega=2*M_PI;

for (int i=0;i< mesh.GetNbElements();i++)
{
	Grads(i)=Grad(i);
	Aires(i)=Aire(i);
	
}


}
	
	
	//******************CALCUL DE L'AIRE***************************
	template<class T>
	double HelmholtzProblem<T>::Aire(int i)
	
	{
		double Aire=0;
		Triangle ti=mesh.Element(i);
		
		const R2 S1=mesh.Vertex(ti.numVertex(0));
		const R2 S2=mesh.Vertex(ti.numVertex(1));
		const R2 S3=mesh.Vertex(ti.numVertex(2));
		
		Aire=(S2(0)-S1(0))*(S3(1)-S1(1))-(S2(1)-S1(1))*(S3(0)-S1(0));
		Aire=Aire/2;
		
		return Aire;
		
	}
	
	//****************************GRADIENT**************************
	template<class T>
	TinyVector<R2, 3> HelmholtzProblem<T>::Grad(int i)
	{
		TinyVector<R2, 3> Grad;
		
		Triangle ti=mesh.Element(i);
	
		const R2 S1=mesh.Vertex(ti.numVertex(0));
		const R2 S2=mesh.Vertex(ti.numVertex(1));
		const R2 S3=mesh.Vertex(ti.numVertex(2));
	
		Grad(0)(0)=(S2(1)-S3(1))/(2*Aire(i));
		Grad(0)(1)=(S3(0)-S2(0))/(2*Aire(i));
		Grad(1)(0)=(S3(1)-S1(1))/(2*Aire(i));
		Grad(1)(1)=(S1(0)-S3(0))/(2*Aire(i));
		Grad(2)(0)=(S1(1)-S2(1))/(2*Aire(i));
		Grad(2)(1)=(S2(0)-S1(0))/(2*Aire(i));
	
	return Grad;

	}
	//*********************** D H ***********************************
	template<class T>
	Vector<T> HelmholtzProblem<T>:: Dh()
	{
	 Dh_.Reallocate(mesh.GetNbVertices());
		Dh_.Zero();
		for(int i=0; i<mesh.GetNbElements();i++)
		{
			Triangle ti=mesh.Element(i);
			for (int jloc=0; jloc<3;jloc++)
			{
				int j;
				j=ti.numVertex(jloc);
				Dh_(j)+=Aire(i)/3;	
				
				//cout << j << " "<< Dh(j)<< endl ;
			}	
		}
		
		return Dh_;
		
	}

   //************************ K H ***********************************
template<class T>
SparseMatrix<T> HelmholtzProblem<T>::Kh()
{
	Kh_.Reallocate(mesh.GetNbVertices(),mesh.GetNbVertices());

	
	for (int i=0; i<mesh.GetNbElements(); i++)
	{
		
	Triangle ti=mesh.Element(i);
		for (int j1=0 ;j1<3; j1++)
		{
			
		for (int j2=0 ;j2<3; j2++)
		{
			int S1=ti.numVertex(j1);
		int S2=ti.numVertex(j2);
	
	double coef=0;
 coef=DotProd(Grad(i)(j1),Grad(i)(j2));
	coef=Aire(i)*coef;
		Kh_.AddInteraction(S1,S2,coef);
		 
		
		//double coef=Grad(i)(j1)(0)*Grad(i)(j2)(0)+Grad(i)(j1)(1)*Grad(i)(j2)(1);
		//coef=Aire(i)*coef;
		//Kh.AddInteraction(S1,S2,coef);
	}
}
}
return Kh_;
}
	
	
	//****************************** Vecteur F ***********************
	
	template<class T>
	double HelmholtzProblem<T>::Gaussian(double x, double y)
{
  return exp(-7*((x-xo_)*(x-xo_)+(y-yo_)*(y-yo_)));
}



template<class T>
Vector<T> HelmholtzProblem<T>::VectorF(Vector<T> D)
{
		Vector <T> VectorF(D.GetM());
		
		for (int i=0; i<mesh.GetNbVertices(); i++)
		{
		VectorF(i)=D(i)*Gaussian(mesh.Vertex(i)(0),mesh.Vertex(i)(1));
}
return VectorF;
}





   //************************* Sh *****************************
   template<class T>
Vector<T> HelmholtzProblem<T>:: Sh()
{
	Sh_.Reallocate(mesh.GetNbVertices());
	

		Sh_.Zero();
		for(int i=0; i<mesh.GetNbEdgesRef();i++)
		{
			if (mesh.EdgeRef(i).GetReference()==2)
			{
			Edge2D ci=mesh.EdgeRef(i);
			for (int jloc=0; jloc<2;jloc++)
			{
				int j;
				R2 Ei=mesh.Vertex(ci.numVertex(0))-mesh.Vertex(ci.numVertex(1));
				j=ci.numVertex(jloc);
				Sh_(j)+=Norm2(Ei)/2;	
				
			}
		}
			else
			 {
			continue;
		}	
		}
		
		return Sh_;
		
	}

	//************************** Ah *******************************
	
	
	template<class T>
SparseMatrix<complex<double>> HelmholtzProblem<T>::Ah()
{
 Ah_.Reallocate(mesh.GetNbVertices(),mesh.GetNbVertices());

		complex<double> z(0,1);
		
	for (int n=0; n<mesh.GetNbVertices(); n++)
	{
		for( int m=0; m<Kh_.GetRowSize(n); m++)
		{
		 int j=Kh_.Index(n,m);	
			Ah_.AddInteraction(n,j,Kh_(n,j));
		}

			Ah_.AddInteraction(n,n,-omega*omega*Dh_(n)-z*omega*Sh_(n));
		}
		
	return Ah_;
}
