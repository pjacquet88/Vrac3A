#include <iostream>
#include <complex>
#include <vector>
#include "linalg/Linalg.hxx"
#include "SparseVector.hxx"
using namespace std;
using namespace linalg;

template<class T>
class SparseMatrix
{
private:
  Vector<SparseVector<T> > val_;
  int m_, n_;

public:
  // methodes de la classe


  SparseMatrix();


  SparseMatrix(int a, int b);

  void Reallocate(int a, int b);

  int GetM() const;

  int GetN() const;

  int GetRowSize(int i);
 
  void Clear();

  void ReallocateRow(int i, int n);

  void ClearRow(int i);

  int& Index(int i,int j);

  T& Value(int i,int j);

  void AddInteraction(int i,int j, const T& x);

  int Index(int i,int j) const;

  T Value(int i,int j) const;
};
