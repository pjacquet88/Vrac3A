#include <iostream>
#include <math.h>
#include "SparseVector.cxx"
#include "SparseMatrix.cxx"
#include <complex>

int main()
{

  SparseVector<double> v;

// on alloue v avec 3 elements non-nuls:
v.Reallocate(3);

// on peut modifier v avec Index/Value
// on a pris ici l'exemple donne au-dessus
v.Index(0) = 0;
v.Index(1) = 3;
v.Index(2) = 5;
  
v.Value(0) = 1.2;
v.Value(1) = -3.0;
v.Value(2) = 2.4;

cout << "Nombre d'elements non-nuls " << v.GetM() << endl;
 cout << "le vecteur" << v << endl;

 v.Resize(4);
 cout << "le vecteur" << v << endl;

 v.Clear();
 cout << "le vecteur" << v << endl;



// puis rajouter les elements avec AddInteraction
// dans l'ordre qu'on souhaite puisque AddInteraction placera la
// valeur au bon endroit
v.AddInteraction(5, 2.4);
 cout << "le vecteur" << v << endl;

v.AddInteraction(0, 1.2);
 cout << "le vecteur" << v << endl;

v.AddInteraction(3, -3.0);
 cout << "le vecteur" << v << endl;

// si on ajoute la valeur sur une colonne deja existante
// les valeurs s'additionnent
v.AddInteraction(5, 0.8);

// on doit obtenir 3.2 pour la colonne 5
cout << "v = " << v << endl;

 SparseMatrix<double> A(12,10);

 int m = 12, n = 10, nnz = 30;
 //A.Reallocate(m, n);
 double val;
// on remplit aleatoirement la matrice
// GetRand est fourni dans linalg
for (int k = 0; k < nnz; k++)
  {
    int i = rand()%m;
    int j = rand()%n;
    GetRand(val);
    A.AddInteraction(i, j, val);
  }

// on affiche la matrice
DISP(A);

// On affiche le nombre d'elements non-nuls sur une ligne
cout << "Taille de la ligne 3 = " << A.GetRowSize(3) << endl;

// on efface la ligne 10, pour la remplacer par autre chose
A.ClearRow(10);

A.ReallocateRow(10, 1);
A.Index(10, 0) = 5;
A.Value(10, 0) = -0.8;

// on peut ensuite effacer toute la matrice
A.Clear();
}
