#include "TP7.hxx"

AdvectionInitialFunction::AdvectionInitialFunction(double L)
{
  L_=L;
  
}

double AdvectionInitialFunction::TranslateX(double y)
{
  double x=y;
  if (x>=L_)
    {
      while (x>=L_)
	{
	  x=x-2*L_;
	}
    }
  else if (x<=-L_)
    {
      while (x<=-L_)
	{
	  x=x+2*L_;
	}
     
    }
  return x;
}

double AdvectionInitialFunction::GetU0(double x)
{
  double y;
  y=TranslateX(x);
  y=(*uo)(y);  // pointeur et non référence
  return y;
}

void AdvectionInitialFunction::SetFunction(double(*f)(double))
{
  uo=f;
}

AdvectionProblem:: AdvectionProblem()
{
	}
	
AdvectionProblem::AdvectionProblem(double L, int N, double a)
{
  L_=L;
  N_=N;
  Vector<double> x(N_);
  x.Zero();
  a_=a;
  for (int i=0;i<N;i++)
    {
      x(i)=-L+(2*i*L_)/(N_+1);
    }
  x_=x;
}

void AdvectionProblem::WriteGnuPlot(const Vector<double>& y, const string& name) const
{
ofstream file_out(name.data());
  for(int i=0;i<N_;i++)
    {
      file_out<<x_(i)<<" "<<y(i)<<endl;
    }
  file_out.close();
}

void AdvectionProblem::AddFunction(double alpha, const Vector<double>& rho, double t, Vector<double>& y)
{ 
	 const int N=y.GetSize();
	double dx=2*L_/(N_+1);

	if (a_>0)

	{
	
		y(0)+=alpha*a_/dx*(rho(N-1)-rho(0));
	for (int i=1;i<N;i++)
    {
      y(i)+=alpha*a_/dx*(rho(i-1)-rho(i));
    }
}	
else

{
	y(N-1)+=-alpha*a_/dx*(rho(0)-rho(N-1));
	for (int i=0;i<N;i++)
	
    {
      y(i)+=-alpha*a_/dx*(rho(i+1)-rho(i));
    }
   
}

}

//*****************SCHEMA***LAXFRIEDRICHS*************************

LaxFriedrichs::LaxFriedrichs(double L,int N, double a)
{
  dt = 0;
  L_=L;
  N_=N;
  a_=a;
  
  Vector<double> x(N_);
   for (int i=0;i<N;i++)
    {
      x(i)=-L+(2*i*L_)/(N_+1);
    }
  x_=x;
  
}


//! retourne U^n
Vector<double>& LaxFriedrichs::GetIterate()
{
  return U;
}

//! retourne U^n
const Vector<double>& LaxFriedrichs::GetIterate() const
{
  return U;
}

//! fonction pour initialiser le schema en temps
void LaxFriedrichs::
SetInitialCondition(double t0, double dt_, Vector<double>& U0, VirtualOdeSystem& sys)
{
  // on detruit U0 quand on en a plus besoin
  dt = dt_;
  U=U0;
  U0.Clear();
  U_next = U;
}

//! fonction principale qui avance le schema en temps
void LaxFriedrichs::Advance(int n, double tn, VirtualOdeSystem& sys)
{
  // LaxFreidrichs 
 U(N_);
 U_next(N_);
 
 double dx=2*L_/N_;
 
 U_next(0)=0.5*(U(1)+U(N_-1))-((a_*dt)/(2*dx))*(U(1)-U(N_-1)); // U(0)
 
 for(int i=1; i<(N_-1); i++)
 {
 U_next(i)=0.5*(U(i+1)+U(i-1))-((a_*dt)/(2*dx))*(U(i+1)-U(i-1));
}

U_next(N_-1)=0.5*(U(0)+U(N_-2))-((a_*dt)/(2*dx))*(U(0)-U(N_-2)); // u(N-1)

U=U_next;
}

void LaxFriedrichs::WriteGnuPlotLF(Vector<double>& y, string s)
{
	ofstream file_out(s.data());
	
	for (int i=0; i<N_; i++)
	{
		file_out << x_(i) << " " << y(i) << endl;
	}
	file_out.close();
}



//***********************SCHEMA LAX WENDROFF***********************************	

LaxWendroff::LaxWendroff(double L,int N, double a)
{
  dt = 0;
  L_=L;
  N_=N;
  a_=a;
  
  Vector<double> x(N_);
   for (int i=0;i<N;i++)
    {
      x(i)=-L+(2*i*L_)/(N_+1);
    }
  x_=x;
  
}


//! retourne U^n
Vector<double>& LaxWendroff::GetIterate()
{
  return U;
}

//! retourne U^n
const Vector<double>& LaxWendroff::GetIterate() const
{
  return U;
}

//! fonction pour initialiser le schema en temps
void LaxWendroff::
SetInitialCondition(double t0, double dt_, Vector<double>& U0, VirtualOdeSystem& sys)
{
  // on detruit U0 quand on en a plus besoin
  dt = dt_;
  U=U0;
  U0.Clear();
  U_next = U;
}

//! fonction principale qui avance le schema en temps
void LaxWendroff::Advance(int n, double tn, VirtualOdeSystem& sys)
{
  // LaxFreidrichs 
 U(N_);
 U_next(N_);
 
 double dx=2*L_/N_;
 
 U_next(0)=U(0)-(a_*dt)*(U(1)-U(N_-1))/(2*dx)+(a_*dt)*(a_*dt)*(U(1)-2*U(0)+U(N_-1))/(2*dx*dx); //! cas i=0

 
 for(int i=1; i<(N_-1); i++)
 {
 U_next(i)=U(i)-(a_*dt)*(U(i+1)-U(i-1))/(2*dx)+(a_*dt)*(a_*dt)*(U(i+1)-2*U(i)+U(i-1))/(2*dx*dx); //! cas i=0
}

U_next(N_-1)=U(N_-1)-(a_*dt)*(U(0)-U(N_-2))/(2*dx)+(a_*dt)*(a_*dt)*(U(0)-2*U(N_-1)+U(N_-2))/(2*dx*dx); //! cas i=0
U=U_next;
}

//*****************************Schema Centré ***************************


SchemaCentre:: SchemaCentre()
{
}




SchemaCentre::SchemaCentre(double L, int N, double a)
{
  L_=L;
  N_=N;
  Vector<double> x(N_);
  x.Zero();
  a_=a;

  for (int i=0;i<N;i++)
    {
		
      x(i)=-L+(2*i*L_)/(N_+1);
    }
    x_.Reallocate(N);
    
	x_=x;
	
}
void SchemaCentre::AddFunction(double alpha, const Vector<double>& u, double t, Vector<double>& y)
{
	double dx=2*L_/(N_+1);	
	
  double beta=a_*alpha/(2.*dx);
  y(0) += beta*(u(N_-1)-u(1));
  for(int i = 1 ; i < N_-1 ; i++)
    {
      y(i) += beta*(u(i-1)-u(i+1));
    }
  y(N_-1) += beta*(u(N_-2)-u(0));
  
  
    
  }
  



