#ifndef LINALG_FILE_MATRIX_TRIDIAG_CXX

#include "MatrixTridiag.hxx"

namespace linalg
{

  //! Constructeur par defaut (matrice de taille nulle)
  template<class T>
  SymmetricTridiagMatrix<T>::SymmetricTridiagMatrix()
  {
  }


  //! Constructeur avec la taille de la matrice
  template<class T>
  SymmetricTridiagMatrix<T>::SymmetricTridiagMatrix(int m, int n)
    : alpha(n-1), delta(n)
  {
    alpha.Zero();
    delta.Zero();
  }
  
  
  //! Initialise une matrice de taille n
  template<class T>
  void SymmetricTridiagMatrix<T>::Reallocate(int m, int n)
  {
    alpha.Reallocate(n-1);
    delta.Reallocate(n);
    alpha.Zero();
    delta.Zero();
  }
  
  
  //! Affectation A(i, j) = val
  template<class T>
  void SymmetricTridiagMatrix<T>::Set(int i, int j, const T& val)
  {
#ifdef LINALG_DEBUG
    if ((i < 0) || (i >= delta.GetM()))
      throw WrongIndex("SymmetricTridiagMatrix::Set()",
		       string("Index along dimension #1 should be in [0, ")
		       + to_string(delta.GetM()-1) + "], but is equal to "
		       + to_string(i) + ".");

    if ((j < 0) || (j >= delta.GetM()))
      throw WrongIndex("SymmetricTridiagMatrix::Set()",
		       string("Index along dimension #2 should be in [0, ")
		       + to_string(delta.GetM()-1) + "], but is equal to "
		       + to_string(j) + ".");
#endif
    
    if (i == j)
      delta(i) = val;    
    else if (i == j-1)
      alpha(i) = val;    
    else if (i == j+1)
      alpha(i-1) = val;
    else
      {
	throw WrongIndex();
      }
  }

  
  //! retourne la valeur A(i, j)
  template<class T>
  const T SymmetricTridiagMatrix<T>::operator()(int i, int j) const
  {
#ifdef LINALG_DEBUG
    if ((i < 0) || (i >= delta.GetM()))
      throw WrongIndex("SymmetricTridiagMatrix::Set()",
		       string("Index along dimension #1 should be in [0, ")
		       + to_string(delta.GetM()-1) + "], but is equal to "
		       + to_string(i) + ".");

    if ((j < 0) || (j >= delta.GetM()))
      throw WrongIndex("SymmetricTridiagMatrix::Set()",
		       string("Index along dimension #2 should be in [0, ")
		       + to_string(delta.GetM()-1) + "], but is equal to "
		       + to_string(j) + ".");
#endif
    
    if (i == j)
      return delta(i);
    else if (i == j-1)
      return alpha(i);
    else if (i == j+1)
      return alpha(i-1);

    return T(0);
  }
  
  
  //! Effectue la factorisation LU de la matrice
  template<class T>
  void SymmetricTridiagMatrix<T>::Factorize()
  {
    int n = delta.GetM();
    T invDelta, pivot;
    for (int i = 0; i < n-1; i++)
      {
	// elimination de alpha
	invDelta = 1.0/delta(i);
	pivot = alpha(i)*invDelta;
	delta(i+1) -= pivot*alpha(i);
	
	//on stocke le coefficient de L dans alpha
	alpha(i) = pivot;
	
	// on remplace la diagonale par son inverse
	delta(i) = invDelta;
      }
    
    delta(n-1) = 1.0/delta(n-1);
  }
  
  
  //! Effectue la phase de resolution, x est en entree la source, en sortie la solution
  template<class T>
  void SymmetricTridiagMatrix<T>::Solve(Vector<T>& x)
  {
    int n = delta.GetM();
    for (int i = 1; i < n; i++)
      x(i) -= alpha(i-1)*x(i-1);
    
    x(n-1) *= delta(n-1);
    for (int i = n-2; i >= 0; i--)
      x(i) = x(i)*delta(i) - alpha(i)*x(i+1);
  }
  
}

#define LINALG_FILE_MATRIX_TRIDIAG_CXX
#endif

