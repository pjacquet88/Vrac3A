#include <math.h>
#include "linalg/Linalg.hxx"
#include "linalg/Vector.hxx"
#include "Mesh2D.hxx"
using namespace linalg;


//****************Helmholtz Problem***************
template<class T>
class HelmholtzProblem
{
	private : 

Vector<TinyVector<R2, 3> > Grads;

Vector<double> Aires;
	
double xo_=-2.5;
double yo_=0;	
	
Vector<T> Dh_;

Vector<T> Sh_;

SparseMatrix<T> Kh_;

SparseMatrix<complex<double>> Ah_;


public:
  //! pulsation omega
  double omega;

  //! centre de la source gaussienne
  R2 center_source;

  //! maillage utilise
  Mesh2D mesh;

// Constructeur

HelmholtzProblem();

double Aire(int i);

TinyVector<R2, 3> Grad(int i);
	
Vector<T> Dh();

SparseMatrix<T> Kh();

double Gaussian(double, double);

Vector<T> VectorF(Vector<T>);


Vector<T> Sh();

SparseMatrix <complex<double>> Ah();


};












