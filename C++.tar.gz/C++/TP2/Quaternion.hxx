#include <iostream>
#include <complex>
using namespace std;

class quaternion
{
private :
    // on mets les donnees de la classe, ici a, b, c, d
    double a, b, c, d;

  public :
    // ici on met les methodes et operateurs de la classe
    
    // pour commencer, on place les constructeurs
    // constructeur par defaut (valeurs non initialisees)
    quaternion();

    // constructeur par copie
    quaternion(const quaternion&);

    // constructeur ou on prend un quaternion egal a un reel
    quaternion(double a_);

    // constructeur ou on fournit a, b, c, d
    quaternion(double, double, double, double);

  //methode conj
  quaternion conj() const;

  //methode norme
  double norme() const;
  
    // on met aussi une fonction amie pour afficher un quaternion
    // pour le format d'ecriture on pourra ecrire un quaternion
    // sous la forme (a, b, c, d)  (comme pour les complexes)
    friend ostream& operator <<(ostream&, const quaternion&);
  // surcharge de abs
    friend double abs(const quaternion&);

  // surcharge de =
   quaternion& operator=(double);
   quaternion& operator=(const complex<double>&);
   quaternion& operator=(const quaternion&);

  // surcharge de +=
   quaternion& operator+=(double);
   quaternion& operator+=(const complex<double>&);
   quaternion& operator+=(const quaternion&);


  // surcharge de -=
   quaternion& operator-=(double);
   quaternion& operator-=(const complex<double>&);
   quaternion& operator-=(const quaternion&);



  // surcharge de *=
   quaternion& operator*=(double);
   quaternion& operator*=(const complex<double>&);
   quaternion& operator*=(const quaternion&);



  // surcharge de /=
   quaternion& operator/=(double);
   quaternion& operator/=(const complex<double>&);
   quaternion& operator/=(const quaternion&);




  // surcharge de +
//quaternion operator+(const quaternion& q1, const quaternion& q2);
};



