using namespace linalg;

template<class T>
class SparseVector
{
private:
    Vector<T> val;
    Vector<int> ind;

public:
    // methodes de la classe
    int GetM();
    void Reallocate(int n);
    int& Index(int i);
    T& Value(int i);
    void Resize(int n);
    void Clear();
    void AddInteraction(int i, T x);
    T operator()(int i);

    template<class U>
    friend ostream& operator <<(ostream&, SparseVector<U>&);
};
