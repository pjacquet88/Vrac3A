template<class T>
class SparseMatrix
{
private:
    Vector<SparseVector<T> > val_;
    int m_, n_;

public:
    // methodes de la classe
    SparseMatrix();
    SparseMatrix(int m, int n);
    void Reallocate(int m, int n);
    int GetM();
    int GetN();
    void Clear();
    int GetRowSize(int i);
    void ReallocateRow(int i, int n);
    void ClearRow(int i);
    int& Index(int i, int j);
    T& Value(int i, int j);
    void AddInteraction(int i, int j, T x);
    Vector<T> Mlt(Vector<T>&);
    void ssor(Vector<T>& x, Vector<T>& b);
    T operator()(int i, int j);

    template<class U>
    friend ostream& operator <<(ostream&, SparseMatrix<U>&);
};
