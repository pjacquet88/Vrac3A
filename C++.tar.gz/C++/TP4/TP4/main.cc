#include "SparseVector.cxx"
#include "SparseMatrix.cxx"
#include "LaplacianProblem.cxx"
#include <cmath>

int main()
{
  double xmin = 0, xmax = 1.0;
  int N;
  cout <<"quel valeur de N souhaitez vous ?"<<endl;
  cin >> N;

 double  nbiter;
    cout <<" quel est le nombre d'iteration max  souhaité ?"<< endl;
    cin >> nbiter;
    double  epsilon;
    cout <<" quelle valeur de epsilon souhaitez vous ?"<< endl;
    cin >> epsilon;

  
    
   
    LaplacianProblem<double> var_laplace(xmin, xmax, N);
    Vector<double> b(N*N);
    Vector<double> x(N*N);
    Vector<double> y(N*N);
    Vector<double> z(N*N);
 


    b.Zero();
    x.Zero();
    y.Zero();
    z.Zero();
 

    for(int i=0;i<N;i++)
    {
        b(i)=1;
    }

    SparseMatrix<double> A;
    var_laplace.ConstructMatrix(A);

    SolveJacobi(A, b, x,epsilon, nbiter);
    SolveSsor(A, b, y, epsilon, nbiter);

    char choix;

    cout <<"quel preconditionneur ?"<< endl;
    cout <<"a) identité"<< endl;
    cout<<"b) ssor"<<endl;

    cin >>choix;
    
    switch (choix)
      {

      case 'a' :
	{
	  IdentityPreconditioner<double> precI;
	  ConjugateGradient(A, z, b, precI,epsilon,nbiter);
	  break;
	}
      case 'b' :
	{
	  SsorPreconditioner<double> precS(A);
	  ConjugateGradient(A, z, b, precS,epsilon,nbiter);
	  break;
	}
      default:
	{
	  cout <<"vous ne connaissez pas votre alphabet"<< endl;
	}
      }

    var_laplace.WriteGnuPlot(x, "test_jac.dat");
    var_laplace.WriteGnuPlot(y, "test_ssor.dat");
    var_laplace.WriteGnuPlot(z, "test_gc.dat");

    return 0;
}
