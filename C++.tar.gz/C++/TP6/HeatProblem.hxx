#include "linalg/Linalg.hxx"
#include "linalg/Vector.hxx"
#include "TimeScheme.hxx"
using namespace linalg;
//-----------------------------Classe Principale---------------------


class HeatProblem : public VirtualOdeSystem
{
private:
  double L_;
  int N_;
  Vector<double> x_;

public:
  HeatProblem(double L, int N);
  void WriteGnuPlot(const Vector<double>& y,const string& name) const;
  double GetX(int i) const
  {
    return x_(i);
  };

void AddFunction(double alpha, const Vector<double>& rho, double t, Vector<double>& y);

};
