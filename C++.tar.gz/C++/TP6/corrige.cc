#include "linalg/Linalg.hxx"

using namespace linalg;

#include "TimeScheme.hxx"
#include "TimeScheme.cxx"

int main(int argc, char** argv)
{
  cout.precision(15);

  // choix du schema en temps
  VirtualTimeScheme* time_scheme = NULL;

  int type_schema = 0;
  cout << "Quel schema voulez-vous utiliser ?" << endl;
  cout << "1- Euler explicite" << endl;
  cout << "2- Runge-Kutta explicite peu couteux en memoire" << endl;
  cout << "3- Adams-Bashforth explicite" << endl;
  cin >> type_schema;

  switch (type_schema)
    {
    case 1:
      time_scheme = new ExplicitEulerIterator();
      break;
    case 2:
      time_scheme = new LowStorageRungeKuttaIterator();
      break;
    case 3:
      time_scheme = new AdamsBashforthIterator();
      break;
    default:
      cout << "Schema inconnu" << endl;
      abort();
    }
    
  // choix du systeme a resoudre
  VirtualOdeSystem* sys = NULL;
  
  int type_system = 0;
  cout << "Quel systeme voulez-vous resoudre" << endl;
  cout << "1- rho'= rho " << endl;
  cout << "2- rho'= t rho^2 " << endl;
  cout << "3- rho'' + k^2 rho = 0" << endl;
  cout << "4- System proie-predateur" << endl;
  cin >> type_system;
  
  switch (type_system)
    {
    case 1:
      sys = new FirstClassOdeSystem();
      break;
    case 2:
      sys = new SecondClassOdeSystem();
      break;
    case 3:
      sys = new VectorialLinearOdeSystem(2.0*M_PI);
      break;
    case 4:
      sys = new ProiePredateurOdeSystem(0.2, 0.5, 0.001, 0.5);
      break;
    default:
      cout << "Systeme inconnu" << endl;
      abort();
    }
  
  // parametres de la simulation en temps
  double tfinal = 3.0;
  double dt = 0.01;

  // condition initiale
  Vector<double> rho0(1);
  switch (type_system)
    {
    case 1:
      rho0(0) = 1.0;
      break;
    case 2:
      rho0(0) = -2.0;
      break;
    case 3:
      rho0.Reallocate(2);
      rho0(0) = 1.0;
      rho0(1) = 0.0;
      break;
    case 4:
      rho0.Reallocate(2);
      rho0(0) = 1000.0;
      rho0(1) = 10.0;
      tfinal = 100.0;
      break;
    }

  Vector<double> rho_init = rho0;

  // on change dt pour tomber pile sur tfinal
  int nb_iterations = int(ceil(tfinal/dt));
  dt = tfinal / nb_iterations;
  
  // initialisation du schema
  time_scheme->SetInitialCondition(0.0, dt, rho0, *sys);

  // boucle principale en temps
  ofstream file_out("history.dat");
  for (int nt = 0; nt < nb_iterations; nt++)
    {
      double tn = nt*dt;
      // on ecrit l'historique de rho
      file_out << tn << " " << time_scheme->GetIterate() << '\n';

      // on avance le schema en temps
      time_scheme->Advance(nt, tn, *sys);
    }
  
  DISP(nb_iterations*dt);
  double sol_final = time_scheme->GetIterate()(0);
  
  file_out.close();
  
  // on relance le schema avec deux fois plus d'iterations
  rho0 = rho_init;
  dt *= 0.5;
  nb_iterations *= 2;
  
  time_scheme->SetInitialCondition(0.0, dt, rho0, *sys);
  for (int nt = 0; nt < nb_iterations; nt++)
    {
      double tn = nt*dt;

      // on avance le schema en temps
      time_scheme->Advance(nt, tn, *sys);
    }

  DISP(nb_iterations*dt);
  
  double sol_final_raff = time_scheme->GetIterate()(0);

  double sol_ref = 0.0;
  switch (type_system)
    {
    case 1:
      sol_ref = exp(tfinal);
      break;
    case 2:
      sol_ref = -2.0/(1.0+tfinal*tfinal);
      break;
    case 3:
      sol_ref = cos(2.0*M_PI*tfinal);
      break;
    }
  
  DISP(sol_ref);
  if (sol_ref != 0.0)
    {
      double err1 = abs(sol_final-sol_ref)/abs(sol_ref);
      cout << "Erreur pour dt = " << err1 << endl;
      double err2 = abs(sol_final_raff-sol_ref)/abs(sol_ref);
      cout << "Erreur pour dt/2 = " << err2 << endl;
      double order = (log(err1) - log(err2))/log(2);
      cout << "Ordre mesure = " << order << endl;
    }

  // on desalloue les pointeurs
  delete time_scheme;
  delete sys;

  return 0;
}
