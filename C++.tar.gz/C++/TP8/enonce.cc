#include "linalg/Linalg.hxx"

using namespace linalg;

#include "Mesh2D.cxx"

int main(int argc, char** argv)
{
  // on prend en argument le nom du maillage
  if (argc < 2)
    {
      cout << "Entrez un nom de maillage" << endl;
      cout << "Usage : ./run example.mesh" << endl;
      abort();
    }

  string name_mesh(argv[1]);
  cout << "Maillage qu'on veut lire = " << name_mesh << endl;
  Mesh2D mesh;
  mesh.Read(name_mesh);
  return 0;
}
